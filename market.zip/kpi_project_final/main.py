from fastapi import FastAPI
from apis import k1, k2, k3, k4, k5, k6, k7, k8, k9, k10,k11,k12,k13,k14,k15

app = FastAPI(title="KPI Aggregator API")

@app.get("/")
def root():
    return {"message": "Welcome to the KPI Aggregator API"}

@app.post("/kpi/1")
def run_kpi_1(params: dict):
    return k1.run_kpi(params)

@app.post("/kpi/2")
def run_kpi_2(params: dict):
    return k2.run_kpi(params)

@app.post("/kpi/3")
def run_kpi_3(params: dict):
    return k3.run_kpi(params)

@app.post("/kpi/4")
def run_kpi_4(params: dict):
    return k4.run_kpi(params)

@app.post("/kpi/5")
def run_kpi_5(params: dict):
    return k5.run_kpi(params)

@app.post("/kpi/6")
def run_kpi_6(params: dict):
    return k6.run_kpi(params)

@app.post("/kpi/7")
def run_kpi_7(params: dict):
    return k7.run_kpi(params)

@app.post("/kpi/8")
def run_kpi_8(params: dict):
    return k8.run_kpi(params)

@app.post("/kpi/9")
def run_kpi_9(params: dict):
    return k9.run_kpi(params)

@app.post("/kpi/10")
def run_kpi_10(params: dict):
    return k10.run_kpi(params)
@app.post("/kpi/11")
def run_kpi_11(params: dict):
    return k11.run_kpi(params)

@app.post("/kpi/12")
def run_kpi_12(params: dict):
    return k12.run_kpi(params)

@app.post("/kpi/13")
def run_kpi_13(params: dict):
    return k13.run_kpi(params)

@app.post("/kpi/14")
def run_kpi_14(params: dict):
    return k14.run_kpi(params)

@app.post("/kpi/15")
def run_kpi_15(params: dict):
    return k15.run_kpi(params)
