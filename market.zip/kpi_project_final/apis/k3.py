import pandas as pd
import matplotlib.pyplot as plt

def extract_kpi_data(file_path):
    """
    Extracts relevant KPI data from a CSV file.

    Args:
        file_path (str): The path to the CSV file.

    Returns:
        pandas.DataFrame: A DataFrame containing the extracted data, or None if an error occurs.
    """
    try:
        df = pd.read_csv(file_path, header=None, skiprows=5)  # Skip initial blank rows

        # Find the row where the actual data starts (look for "Entry ID")
        start_row = None
        for i in range(len(df)):
            if "Entry ID" in df.iloc[i].values:
                start_row = i
                break

        if start_row is None:
            print(f"Error: Could not find header row ('Entry ID') in {file_path}")
            return None

        # Extract the header row
        header = df.iloc[start_row].tolist()

        # Extract the data rows
        data = df.iloc[start_row + 1:].values.tolist()

        # Create the DataFrame
        extracted_df = pd.DataFrame(data, columns=header)

        # Clean up the DataFrame (remove rows with missing values in key columns)
        extracted_df = extracted_df.dropna(subset=['Trend Category', 'Description', 'Source', 'Date Identified', 'Source URL'])

        return extracted_df

    except FileNotFoundError:
        print(f"Error: File not found at {file_path}")
        return None
    except pd.errors.EmptyDataError:
        print(f"Error: File {file_path} is empty.")
        return None
    except Exception as e:
        print(f"Error occurred while processing {file_path}: {e}")
        return None


def summarize_trend_categories(df):
    """
    Summarizes the trend categories and their frequency.

    Args:
        df (pandas.DataFrame): The DataFrame containing the KPI data.

    Returns:
        pandas.DataFrame: A DataFrame containing the summarized data.
    """
    if df is None or df.empty:
        print("Error: No data to summarize.")
        return None

    trend_counts = df['Trend Category'].value_counts().reset_index()
    trend_counts.columns = ['Trend Category', 'Count']
    trend_counts = trend_counts.sort_values('Count', ascending=False)

    return trend_counts


def visualize_trend_categories(trend_counts):
    """
    Visualizes the trend categories and their frequency using a bar chart.

    Args:
        trend_counts (pandas.DataFrame): The DataFrame containing the summarized trend counts.
    """
    if trend_counts is None or trend_counts.empty:
        print("Error: No data to visualize.")
        return

    plt.figure(figsize=(10, 6))
    plt.bar(trend_counts['Trend Category'], trend_counts['Count'], color='mediumseagreen')
    plt.xlabel("Trend Category")
    plt.ylabel("Number of Mentions")
    plt.title("Frequency of Key Market Trends")
    plt.xticks(rotation=45, ha='right')
    plt.tight_layout()
    plt.show()


def main(file_path):
    """
    Main function to execute the KPI data extraction, summarization, analysis, and visualization.

    Args:
        file_path (str): The path to the KPI CSV file.
    """
    # 1. Extract KPI data
    kpi_df = extract_kpi_data(file_path)

    if kpi_df is not None:
        print("\nExtracted KPI Data:")
        print(kpi_df.head())  # Display the first few rows of the extracted data

        # 2. Summarize trend categories
        trend_counts = summarize_trend_categories(kpi_df)

        if trend_counts is not None:
            print("\nTrend Category Counts:")
            print(trend_counts)

            # 3. Visualize trend categories
            visualize_trend_categories(trend_counts)

    else:
        print("KPI data extraction failed.  Please check the file and extraction process.")


# Example usage:
if __name__ == "__main__":
    file_path = "KPI-3.csv"  # Replace with the actual path to your file
    main(file_path)


# Example usage:
if __name__ == "__main__":
    file_path = "KPI-3.csv"  # Replace with the actual path to your file
    main(file_path)


def run_kpi(params):
    file_path = params.get("file_path", "KPI-3.csv")
    df = extract_kpi_data(file_path)

    if df is not None and not df.empty:
        trend_counts = summarize_trend_categories(df)

        if trend_counts is not None and not trend_counts.empty:
            top_trend = trend_counts.iloc[0]
            return {
                "kpi_name": "Key Market Trends",
                "top_trend_category": top_trend['Trend Category'],
                "mentions": int(top_trend['Count']),
                "total_trend_categories": len(trend_counts)
            }
        else:
            return {
                "kpi_name": "Key Market Trends",
                "error": "No trend category summary available."
            }
    else:
        return {
            "kpi_name": "Key Market Trends",
            "error": "No data extracted from file."
        }