import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load and clean data
df = pd.read_csv('data\KPI-4.csv', skiprows=2)  # Skip both header rows

# Clean column names and handle the structure
df.columns = ['Sr_No', 'Date', 'Category', 'Search_Term', 'Relative_Interest', 'Platform_Link']

# Remove any empty rows
df = df.dropna(subset=['Date', 'Category', 'Relative_Interest'])

# Convert date and sort
df['Date'] = pd.to_datetime(df['Date'])
df = df.sort_values('Date')

print(f"Data loaded: {len(df)} records")

# Basic analysis
print("=== TREND STRENGTH ANALYSIS ===\n")

# Summary by category
summary = df.groupby('Category')['Relative_Interest'].agg(['mean', 'max', 'min', 'count']).round(1)
print("Category Performance Summary:")
print(summary)

# Recent trends (last 6 months)
recent = df[df['Date'] >= '2024-12-01']
recent_avg = recent.groupby('Category')['Relative_Interest'].mean().round(1)
print(f"\nRecent Average Interest (Dec 2024 onwards):")
for cat, score in recent_avg.items():
    print(f"  {cat}: {score}")

# Trend direction
print(f"\nTrend Direction (2024-2025):")
for category in df['Category'].unique():
    cat_data = df[df['Category'] == category].tail(12)  # Last 12 records
    if len(cat_data) > 1:
        trend = "📈 Rising" if cat_data['Relative_Interest'].iloc[-1] > cat_data['Relative_Interest'].iloc[0] else "📉 Declining"
        change = cat_data['Relative_Interest'].iloc[-1] - cat_data['Relative_Interest'].iloc[0]
        print(f"  {category}: {trend} ({change:+.1f} points)")

# Peak months
print(f"\nPeak Performance:")
for category in df['Category'].unique():
    cat_data = df[df['Category'] == category]
    peak = cat_data.loc[cat_data['Relative_Interest'].idxmax()]
    print(f"  {category}: {peak['Relative_Interest']} ({peak['Date'].strftime('%Y-%m')})")

# Visualizations
fig, axes = plt.subplots(2, 2, figsize=(15, 10))
fig.suptitle('Trend Strength Analysis Dashboard', fontsize=16)

# Line plot - trends over time
for category in df['Category'].unique():
    cat_data = df[df['Category'] == category]
    axes[0,0].plot(cat_data['Date'], cat_data['Relative_Interest'], 
                   marker='o', label=category, linewidth=2)
axes[0,0].set_title('Search Interest Over Time')
axes[0,0].legend()
axes[0,0].tick_params(axis='x', rotation=45)

# Bar plot - average interest
summary['mean'].plot(kind='bar', ax=axes[0,1], color=['skyblue', 'lightcoral', 'lightgreen'])
axes[0,1].set_title('Average Search Interest by Category')
axes[0,1].tick_params(axis='x', rotation=45)

# Box plot - distribution
df.boxplot(column='Relative_Interest', by='Category', ax=axes[1,0])
axes[1,0].set_title('Interest Distribution by Category')

# Recent trends
recent.groupby('Category')['Relative_Interest'].mean().plot(kind='pie', 
                                                           ax=axes[1,1], 
                                                           autopct='%1.1f%%')
axes[1,1].set_title('Recent Interest Share')

plt.tight_layout()
plt.show()

# Quick insights
print(f"\n=== KEY INSIGHTS ===")
strongest = summary['mean'].idxmax()
print(f"📊 Strongest Overall Trend: {strongest} ({summary.loc[strongest, 'mean']} avg)")

most_volatile = (summary['max'] - summary['min']).idxmax()
print(f"🌊 Most Volatile: {most_volatile}")

fastest_growing = recent_avg.idxmax()
print(f"🚀 Currently Hottest: {fastest_growing} ({recent_avg[fastest_growing]} recent avg)")