import pandas as pd
import re
from collections import defaultdict
import matplotlib.pyplot as plt
import seaborn as sns

# ✅ Step 1: Load your file
csv_path = "C:/Users/Lenovo/OneDrive/Desktop/representation/KPI-6.csv"
df = pd.read_csv(csv_path)

# ✅ Step 2: Define technology keywords
technology_keywords = [
    'AI', 'Artificial Intelligence', 'Machine Learning', 'Blockchain', 'IoT',
    'Smart Packaging', 'Sustainable Packaging', 'Automation', 'Robotics',
    'Data Analytics', 'Cloud Computing', 'Digital Twin', 'Sensor Technology'
]

# ✅ Step 3: Define relevance descriptions
tech_descriptions = {
    'AI': 'Used for demand forecasting, quality control, and process optimization.',
    'Artificial Intelligence': 'Used for automation and intelligent decision-making in supply chains.',
    'Machine Learning': 'Helps predict spoilage, consumer preferences, and optimize logistics.',
    'Blockchain': 'Improves traceability and transparency in the food supply chain.',
    'IoT': 'Enables real-time monitoring of storage, temperature, and logistics.',
    'Smart Packaging': 'Improves shelf life and provides freshness indicators.',
    'Sustainable Packaging': 'Reduces environmental impact and supports circular economy.',
    'Automation': 'Enhances food processing efficiency and reduces human error.',
    'Robotics': 'Used in harvesting, packaging, and processing to increase speed and safety.',
    'Data Analytics': 'Helps in making informed decisions using production and sales data.',
    'Cloud Computing': 'Enables centralized access to data and real-time processing.',
    'Digital Twin': 'Simulates supply chain processes for better optimization.',
    'Sensor Technology': 'Monitors environmental conditions like humidity and temperature.'
}

# ✅ Step 4: Combine text from all columns
text_data = df.astype(str).apply(lambda row: ' '.join(row), axis=1)

# ✅ Step 5: Find technology mentions
tech_mentions = defaultdict(list)

for row_text in text_data:
    for tech in technology_keywords:
        if re.search(rf'\b{re.escape(tech)}\b', row_text, re.IGNORECASE):
            context = row_text[:300] + "..." if len(row_text) > 300 else row_text
            tech_mentions[tech].append(context)

# ✅ Step 6: Build summary
summary = []
for tech, contexts in tech_mentions.items():
    summary.append({
        "Technology": tech,
        "Mentions": len(contexts),
        "Example Context": contexts[0] if contexts else "N/A",
        "Relevance Description": tech_descriptions.get(tech, "N/A")
    })

result_df = pd.DataFrame(summary).sort_values(by="Mentions", ascending=False)

# ✅ Step 7: Display table
print(result_df[['Technology', 'Mentions', 'Relevance Description']])

# ✅ Step 8: Create bar chart
plt.figure(figsize=(12, 6))
sns.barplot(x="Mentions", y="Technology", data=result_df, palette="crest")
plt.title("Technology Mentions in Food Sector Data")
plt.xlabel("Number of Mentions")
plt.ylabel("Technology")
plt.tight_layout()
plt.show()

# ✅ Step 9: Save results to CSV
output_path = "C:/Users/Lenovo/OneDrive/Desktop/representation/tech_mentions_summary.csv"
result_df.to_csv(output_path, index=False)