import pandas as pd
import matplotlib.pyplot as plt

# Load the dataset, skip first two rows
df = pd.read_csv("C:/Users/Lenovo/OneDrive/Desktop/representation/KPI-7.csv", skiprows=2)

# Rename columns
df.columns = [
    "Sr_No", "Date", "Investment_Type", "Investment_Amount", "Investor",
    "Company", "Sector", "Purpose", "Region", "Stage",
    "Strategic_Alignment", "Food_Sector_Impact", "Funding_Stage",
    "Key_People", "Partnerships", "Media_Source", "Impact_on_Haldiram",
    "Notes"
]

# Convert Date to datetime
df['Date'] = pd.to_datetime(df['Date'], errors='coerce')

# Remove rows with invalid dates or missing key data
df = df.dropna(subset=["Date", "Investment_Amount", "Company"])

# Clean investment amounts (e.g., "$300 million" to numeric)
def parse_amount(amount):
    try:
        amount = amount.replace('$', '').replace(',', '').lower()
        if 'million' in amount:
            return float(amount.replace('million', '').strip()) * 1_000_000
        elif 'billion' in amount:
            return float(amount.replace('billion', '').strip()) * 1_000_000_000
        else:
            return float(amount)
    except:
        return None

df['Investment_Amount_Num'] = df['Investment_Amount'].apply(parse_amount)

# Drop rows with unparseable amounts
df = df.dropna(subset=["Investment_Amount_Num"])

# Sort by date
df = df.sort_values("Date")

# Display timeline as text
print("📌 Investment Timeline:")
for _, row in df.iterrows():
    print(f"{row['Date'].date()} - {row['Company']} received ${row['Investment_Amount_Num']:,.0f} ({row['Investment_Type']})")

# Plotting timeline
plt.figure(figsize=(12, 6))
plt.scatter(df['Date'], df['Investment_Amount_Num'], color='green', s=100)

for i in range(len(df)):
    plt.text(df['Date'].iloc[i], df['Investment_Amount_Num'].iloc[i], df['Company'].iloc[i], fontsize=9, ha='right', rotation=45)

plt.title("📈 Timeline of Key Investment Events")
plt.xlabel("Date")
plt.ylabel("Investment Amount (USD)")
plt.xticks(rotation=45)
plt.tight_layout()
plt.grid(True)
plt.show()