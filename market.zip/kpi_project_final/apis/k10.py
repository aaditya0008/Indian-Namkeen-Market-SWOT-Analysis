import pandas as pd
import matplotlib.pyplot as plt

# Step 1: Load and clean data
df = pd.read_csv("C:/Users/Lenovo/OneDrive/Desktop/representation/KPI-10.csv", skiprows=2)
df.dropna(how='all', inplace=True)
df['Date'] = pd.to_datetime(df['Date'], errors='coerce')
df = df.dropna(subset=['Date'])

# Step 2: Extract quarter
df['Quarter'] = df['Date'].dt.to_period('Q')

# Step 3: Group and count by quarter
quarterly_trend = df.groupby('Quarter').size()

# Step 4: Plot the trend line
plt.figure(figsize=(10, 5))
quarterly_trend.plot(kind='line', marker='o', linestyle='-', color='blue')
plt.title('Q-commerce Activity Trend (Quarterly)')
plt.xlabel('Quarter')
plt.ylabel('Number of Activities')
plt.grid(True)
plt.tight_layout()
plt.show()

# Step 5: Print summary
summary = {
    "Total Entries": len(df),
    "Tracked Quarters": quarterly_trend.index.astype(str).tolist(),
    "Activity Counts per Quarter": quarterly_trend.to_dict()
}

print(summary)