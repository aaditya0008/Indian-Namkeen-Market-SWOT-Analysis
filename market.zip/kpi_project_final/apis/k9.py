import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from wordcloud import WordCloud
import wordcloud

# Load the dataset
df = pd.read_csv("C:/Users/Lenovo/OneDrive/Desktop/representation/KPI-9.csv", skiprows=2)
df.dropna(how='all', inplace=True)

# General overview
total_entries = len(df)
companies = df['Company'].dropna().unique()
activity_counts = df['Company'].value_counts()
activity_types = df['Activity Type'].value_counts()
sentiment_summary = df['Sentiment'].value_counts()

snack_related = df[df['Category'].str.contains("snack", case=False, na=False)]
snack_count = snack_related.shape[0]
snack_percentage = round((snack_count / total_entries) * 100, 1)



# Get example keywords from description and notes
descriptions = df['Description'].dropna().tolist()
notes = df['Additional Notes'].dropna().tolist()
combined_text = " ".join(descriptions + notes)
sample_excerpt = combined_text[:400] + "..." if combined_text else "N/A"

# Print qualitative summary
print("📋 QUALITATIVE SUMMARY: Q-commerce Growth & Relevance to Snack/Food Delivery\n")
print(f"🧾 Total Entries in Dataset: {total_entries}")
print(f"🏪 Companies Covered: {', '.join(companies)}")
print(f"📊 Activity Types:\n{activity_types.to_string()}")
print(f"\n🔁 Activity Count by Company:\n{activity_counts.to_string()}")
print(f"\n📦 Snack/Food Related Entries: {snack_count} ({snack_percentage}%)")
print(f"\n😊 Sentiment Summary:\n{sentiment_summary.to_string()}")
print("\n💬 Sample Themes from Descriptions/Notes:")
print(sample_excerpt)

# --- Bar chart: Q-commerce activities by company ---
plt.figure(figsize=(8, 5))
sns.countplot(data=df, x='Company', order=df['Company'].value_counts().index, palette='viridis')
plt.title('Q-commerce Activities by Company')
plt.xlabel('Company')
plt.ylabel('Number of Activities')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# --- Pie chart: Distribution of Activity Types ---
activity_counts = df['Activity Type'].value_counts()
plt.figure(figsize=(6, 6))
activity_counts.plot.pie(autopct='%1.1f%%', startangle=140, colors=sns.color_palette('pastel'))
plt.title('Activity Types in Q-commerce')
plt.ylabel('')
plt.tight_layout()
plt.show()