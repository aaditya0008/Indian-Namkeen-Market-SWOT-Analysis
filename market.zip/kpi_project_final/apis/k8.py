import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Load the dataset (skip header rows)
df = pd.read_csv("C:/Users/Lenovo/OneDrive/Desktop/representation/KPI-8.csv", skiprows=2)
# Rename columns
df.columns = [
    "Platform", "Product_Name", "Brand", "Weight_g", "Price_INR",
    "Discount_Percent", "Availability", "Delivery_Time", "Product_Link"
]

# Clean the 'Availability' field
df["Availability"] = df["Availability"].str.strip().str.lower()

# Convert to qualitative rating
def rate_availability(val):
    if val == "in stock":
        return "High"
    elif val == "out of stock":
        return "Low"
    else:
        return "Medium"

df["Qualitative_Rating"] = df["Availability"].apply(rate_availability)

# Summarize counts of ratings per platform
summary = df.groupby("Platform")["Qualitative_Rating"].value_counts().unstack(fill_value=0)

# 🔷 Plot heatmap
plt.figure(figsize=(8, 5))
sns.heatmap(summary, annot=True, cmap="YlGnBu", fmt="d", linewidths=.5, cbar=False)

# Plot settings
plt.title("📊 Platform-wise Product Availability Ratings")
plt.xlabel("Rating")
plt.ylabel("Platform")
plt.tight_layout()

# Show the plot
plt.show()