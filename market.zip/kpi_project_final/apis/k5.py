import pandas as pd
import matplotlib.pyplot as plt

# Load the dataset, skipping metadata rows
file_path = "data\KPI-5.csv"  # Adjust path if needed
df = pd.read_csv(file_path, skiprows=3)

# Rename columns for clarity
df.columns = ['Sr. No.', 'Date', 'Regulatory Change', 'Category', 'Impact Area', 'News Frequency', 'Platform Link']

# Convert 'Date' column to datetime
df['Date'] = pd.to_datetime(df['Date'], errors='coerce')

# Drop rows with invalid or missing dates
df = df.dropna(subset=['Date'])

# Create new columns for Quarter and Year
df['Quarter'] = df['Date'].dt.to_period('Q')
df['Year'] = df['Date'].dt.year

# Count the number of events per quarter
quarterly_counts = df.groupby('Quarter').size().reset_index(name='Event Count')

# Plotting the timeline chart
plt.figure(figsize=(10, 6))
plt.plot(quarterly_counts['Quarter'].astype(str), quarterly_counts['Event Count'], marker='o', linestyle='-')
plt.title('Regulatory Events / News Mentions per Quarter')
plt.xlabel('Quarter')
plt.ylabel('Number of Events')
plt.grid(True)
plt.tight_layout()
plt.xticks(rotation=45)
plt.show()