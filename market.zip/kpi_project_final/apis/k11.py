import pandas as pd

def run_kpi(params):
    file_path = params.get("file_path", "KPI-11.csv")
    df = pd.read_csv(file_path, skiprows=2)
    df.dropna(how='all', inplace=True)
    df['Date'] = pd.to_datetime(df['Date'], errors='coerce')
    df = df.dropna(subset=['Date'])
    df['Quarter'] = df['Date'].dt.to_period('Q')
    quarterly_trend = df.groupby('Quarter').size()
    summary = {
        "kpi_name": "Q-commerce Activity Trend",
        "Total Entries": len(df),
        "Tracked Quarters": quarterly_trend.index.astype(str).tolist(),
        "Activity Counts per Quarter": quarterly_trend.to_dict()
    }
    return summary