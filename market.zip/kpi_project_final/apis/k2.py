import pandas as pd
import matplotlib.pyplot as plt

def extract_kpi_data(file_path):
    """
    Extracts relevant KPI data from a CSV file.

    Args:
        file_path (str): The path to the CSV file.

    Returns:
        pandas.DataFrame: A DataFrame containing the extracted data, or None if an error occurs.
    """
    try:
        df = pd.read_csv(file_path, header=None, skiprows=3)  # Skip initial blank rows

        # Find the row where the actual data starts (look for "Sr. No.")
        start_row = None
        for i in range(len(df)):
            if "Sr. No." in df.iloc[i].values:
                start_row = i
                break

        if start_row is None:
            print(f"Error: Could not find header row ('Sr. No.') in {file_path}")
            return None

        # Extract the header row
        header = df.iloc[start_row].tolist()

        # Extract the data rows
        data = df.iloc[start_row + 1:].values.tolist()

        # Create the DataFrame
        extracted_df = pd.DataFrame(data, columns=header)

        # Clean up the DataFrame (remove rows with missing values in key columns)
        extracted_df = extracted_df.dropna(subset=['Market Category', 'CAGR (%)', 'Time Period'])

        # Convert 'CAGR (%)' to numeric, handling errors. Replace 'N/A' with NaN first.
        extracted_df['CAGR (%)'] = extracted_df['CAGR (%)'].replace('N/A', pd.NA)
        extracted_df['CAGR (%)'] = pd.to_numeric(extracted_df['CAGR (%)'], errors='coerce')

        # Remove rows where conversion to numeric failed
        extracted_df = extracted_df.dropna(subset=['CAGR (%)'])

        return extracted_df

    except FileNotFoundError:
        print(f"Error: File not found at {file_path}")
        return None
    except pd.errors.EmptyDataError:
        print(f"Error: File {file_path} is empty.")
        return None
    except Exception as e:
        print(f"Error occurred while processing {file_path}: {e}")
        return None


def visualize_cagr_line_chart(df):
    """
    Visualizes CAGR trends over time (if Time Period data is suitable) using a line chart.

    Args:
        df (pandas.DataFrame): The DataFrame containing the KPI data.
    """
    if df is None or df.empty:
        print("Error: No data to visualize.")
        return

    # Extract start and end years from the Time Period column
    def extract_years(time_period):
        try:
            start_year, end_year = map(int, time_period.split('–'))
            return start_year, end_year
        except:
            return None, None

    df['Start Year'], df['End Year'] = zip(*df['Time Period'].apply(extract_years))

    # Drop rows where year extraction failed
    df = df.dropna(subset=['Start Year', 'End Year'])

    # Convert years to integers
    df['Start Year'] = df['Start Year'].astype(int)
    df['End Year'] = df['End Year'].astype(int)

    # Create a simplified time representation (midpoint of the period)
    df['Mid Year'] = (df['Start Year'] + df['End Year']) / 2

    # Group by Mid Year and calculate the average CAGR
    cagr_trends = df.groupby('Mid Year')['CAGR (%)'].mean().sort_index()

    # Create the line chart
    plt.figure(figsize=(12, 6))
    plt.plot(cagr_trends.index, cagr_trends.values, marker='o', linestyle='-', color='skyblue')
    plt.xlabel("Midpoint of Time Period")
    plt.ylabel("Average CAGR (%)")
    plt.title("CAGR Trends Over Time")
    plt.grid(True)
    plt.tight_layout()
    plt.show()


def main(file_path):
    """
    Main function to execute the KPI data extraction, analysis, and visualization.

    Args:
        file_path (str): The path to the KPI CSV file.
    """
    # 1. Extract KPI data
    kpi_df = extract_kpi_data(file_path)

    if kpi_df is not None:
        print("\nExtracted KPI Data:")
        print(kpi_df.head())  # Display the first few rows of the extracted data

        # 2. Visualize CAGR trends over time (Line Chart)
        visualize_cagr_line_chart(kpi_df)

    else:
        print("KPI data extraction failed.  Please check the file and extraction process.")



# Example usage:
if __name__ == "__main__":
    file_path = "KPI-2.csv"  
    main(file_path)

    

def run_kpi(params):
    file_path = params.get("file_path", "KPI-2.csv")  # default file name
    df = extract_kpi_data(file_path)

    if df is not None and not df.empty:
        # You can calculate and return some summary stats
        avg_cagr = df["CAGR (%)"].mean()
        return {
            "kpi_name": "CAGR Trend",
            "average_cagr": round(avg_cagr, 2),
            "unit": "%",
            "records_count": len(df)
        }
    else:
        return {
            "kpi_name": "CAGR Trend",
            "error": "No data found or processed"
        }